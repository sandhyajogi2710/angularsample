export class LoginForm {
    name: string;
    email: string;
    pwd: string;
  }
  