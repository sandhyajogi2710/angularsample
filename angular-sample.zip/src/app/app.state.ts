import { LoginForm } from './loginform/loginform.model';

export interface AppState {
   loginform: LoginForm[];
}
