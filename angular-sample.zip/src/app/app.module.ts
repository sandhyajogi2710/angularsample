import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { AppComponent } from './app.component';
import { LoginformComponent } from './loginform/loginform.component';
import { StoreModule } from '@ngrx/store';
import { validateForm } from './reducers/loginform.reducer';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginformComponent,
    
  ],
  imports: [
    BrowserModule,
    StoreModule.forRoot({loginform: validateForm}),
    ReactiveFormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
